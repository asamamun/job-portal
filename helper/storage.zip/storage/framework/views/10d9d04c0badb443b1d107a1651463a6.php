<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('jobentry.inc.jumbotron', ['title' => 'Job Post'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Job Detail Start -->
<div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
    <div class="container">
        <div class="row gy-5 gx-4">
            <div class="col-lg-4">
                <div class="bg-light rounded p-5 mb-4 wow slideInUp" id="functionalSidebar" data-wow-delay="0.1s">
                    <h4 class="mb-4">Functional</h4>
                </div>
                <div class="bg-light rounded p-5 mb-4 wow slideInUp" id="industrialSidebar" data-wow-delay="0.1s">
                    <h4 class="mb-4">Industrial</h4>
                </div>
                <div class="bg-light rounded p-5 mb-4 wow slideInUp" id="specialSidebar" data-wow-delay="0.1s">
                    <h4 class="mb-4">Special</h4>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="row">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 mb-3">
                        <div class="card">
                            <img src="<?php echo e(asset('storage/'.$post->image)); ?>" class="card-img-top" alt="" style="height: 200px;">
                            <div class="card-body">
                                <h5 class="card-title" style="height: 50px;"><?php echo e(Str::limit($post->title, 50)); ?></h5>
                                <p class="card-text" style="height: 100px;"><?php echo e(Str::limit(preg_replace("/&#?[a-z0-9]+;/i", "", strip_tags($post->description)), 100)); ?></p>
                                <a href="<?php echo e(route('post.single', $post->id)); ?>" class="btn btn-primary">View Details</a>
                                <a href="<?php echo e(url('applicant/apply/'.$post->id)); ?>" class="btn btn-primary">Apply Now</a>
                                <a href="<?php echo e(route('post.save', $post->id)); ?>" class="btn btn-primary">Save</a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo e($posts->links()); ?>

            </div>
        </div>
    </div>
</div>
<!-- Job Detail End -->
<?php echo $__env->make('jobentry.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('jobentry.layout', ['title' => 'Job Entry'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\New folder (2)\job-portal\resources\views/jobentry/posts.blade.php ENDPATH**/ ?>
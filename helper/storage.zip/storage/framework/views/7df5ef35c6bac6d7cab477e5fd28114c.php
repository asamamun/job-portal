<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <h4 class="header-title">Update Form</h4>
        

        <form action="<?php echo e(route('carousel.update', $carousel->id)); ?>" class="parsley-examples" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="header" class="form-label">Header<span class="text-danger">*</span></label>
                <input type="text" name="header" required="" value="<?php echo e($carousel->header); ?>" class="form-control" id="header">
            </div>
            <div class="mb-3">
                <label for="title" class="form-label">Title<span class="text-danger">*</span></label>
                <input type="text" name="title" required="" value="<?php echo e($carousel->title); ?>" class="form-control" id="title">
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Image<span class="text-danger">*</span></label>
                <input type="file" name="image" value="<?php echo e($carousel->image); ?>" class="form-control" id="image">
            </div>
            <div class="text-end">
                <button class="btn btn-primary waves-effect waves-light" type="submit">Update</button>
                <button type="reset" class="btn btn-danger waves-effect">Reset</button>
                <button type="reset" class="btn btn-secondary waves-effect">Cancel</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminto.layout.admin', ['title' => 'Job Entry', 'name' => 'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\project\job-portal\resources\views/adminto/carousel/edit.blade.php ENDPATH**/ ?>
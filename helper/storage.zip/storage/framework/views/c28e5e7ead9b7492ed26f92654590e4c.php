<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('jobentry.inc.jumbotron', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid pt-3 pb-3" data-wow-delay="0.1s">
    <div class="container py-5">
        <h1 class="text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">Skill</h1>
        <div class="row g-5">
            <?php echo $__env->make('jobentry.inc.leftsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card col-9">
                <div class="card-body">
                    <h4 class="mt-0 header-title">Skill Add</h4>
                    <form action="<?php echo e(route('skill.store')); ?>" class="parsley-examples" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="skill_type_id" class="form-label">Skill Type<span class="text-danger">*</span></label>
                            <select name="skill_type_id" required id="skill_type_id" class="form-control">
                                <option value="" disabled <?php echo e(old('skill_type_id') ? '' : 'selected'); ?>>Select Skill Type</option>
                                <?php $__currentLoopData = $skilltypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skilltype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($skilltype->id); ?>" <?php echo e(old('skill_type_id') == $skilltype->id ? 'selected' : ''); ?>><?php echo e($skilltype->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="level" class="form-label">Level<span class="text-danger">*</span></label>
                            <select name="level" required id="level" class="form-control">
                                <option value="beginner">Beginner</option>
                                <option value="intermediate">Intermediate</option>
                                <option value="advanced">Advanced</option>
                            </select>
                        </div>
                        <div class="text-end">
                            <button class="btn btn-primary waves-effect waves-light" type="submit">Submit</button>
                            <button type="reset" class="btn btn-danger waves-effect">Reset</button>
                            <button type="button" class="btn btn-secondary waves-effect">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('jobentry.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('jobentry.layout', ['title' => 'Job Entry'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\WDPF-57\Desktop\production\job-portal\resources\views/jobentry/skill/create.blade.php ENDPATH**/ ?>
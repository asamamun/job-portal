<?php if($errors->any()): ?>
	<?php echo e($msg = ""); ?>

	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($msg .= $error); ?>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<script>alert("<?php echo e($msg); ?>")</script>
<?php endif; ?>

<?php if(session('error')): ?>
<script>alert("<?php echo e(session('error')); ?>")</script>
<?php endif; ?>

<?php if(session('success')): ?>
<script>alert("<?php echo e(session('success')); ?>")</script>
<?php endif; ?><?php /**PATH C:\Users\ASUS\Desktop\project\job-portal\resources\views/inc/alert.blade.php ENDPATH**/ ?>
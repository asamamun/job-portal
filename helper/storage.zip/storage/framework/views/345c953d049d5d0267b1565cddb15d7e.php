<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('jobentry.inc.jumbotron', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid pt-3 pb-3" data-wow-delay="0.1s">
    <div class="container py-5">
        <h1 class="text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">Profile</h1>
        <div class="row g-5">
            <?php echo $__env->make('jobentry.inc.leftsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            <div class="card col-9">
                <div class="card-body">
                    <h4 class="mt-0 header-title">Experience Add</h4>
                
                    <table id="datatable" class="table table-bordered dt-responsive table-responsive nowrap">
                        <thead>
                            <tr>
                                <th>Company</th>
                                <th>Address</th>
                                <th>Phone</th>
                                <th>Position</th>
                                <th>Department</th>
                                <th>Description</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Action</th>
                            </tr>
                        </thead>


                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="odd">
                                <td class="" tabindex="0"><?php echo e($experience->company); ?></td>
                                <td class=""><?php echo e($experience->address); ?></td>
                                <td class=""><?php echo e($experience->phone); ?></td>
                                <td class=""><?php echo e($experience->position); ?></td>
                                <td class=""><?php echo e($experience->department); ?></td>
                                <td class=""><?php echo e($experience->description); ?></td>
                                <td class=""><?php echo e(Carbon\Carbon::parse($experience->from)->format('d/m/y')); ?></td>
                                <td class=""><?php echo e($experience->to ? Carbon\Carbon::parse($experience->to)->format('d/m/y') : "continue"); ?></td>

                                <td>
                                    <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                                        <div class="btn-group" role="group">
                                            <button id="btnGroupDrop1" type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="bi bi-arrow-down-square"></i>
                                            </button>
                                            <ul class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                                <li><a class="dropdown-item" href="<?php echo e(route('experience.edit', $experience->id)); ?>">Edit</a></li>
                                                <form action="<?php echo e(route('experience.destroy', $experience->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <li><button class="dropdown-item" type="submit">Delete</button></li>
                                                </form>
                                            </ul>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr class="odd">
                                <td class="text-center" colspan="100" style="color: red;">Empty</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('jobentry.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('jobentry.layout', ['title' => 'Job Entry'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\WDPF-57\Desktop\production\job-portal\resources\views/jobentry/experience/index.blade.php ENDPATH**/ ?>
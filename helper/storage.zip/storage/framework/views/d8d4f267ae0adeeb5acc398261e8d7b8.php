<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('jobentry.inc.jumbotron', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid pt-3 pb-3" data-wow-delay="0.1s">
    <div class="container py-5">
        <h1 class="text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">Profile</h1>
        <div class="row g-5">
            <?php echo $__env->make('jobentry.inc.leftsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <div class="card  col-9">
                <div class="card-body">
                    <h4 class="mt-0 header-title">Experience Details</h4>
                  
                    <form action="<?php echo e(route('experience.store')); ?>" class="parsley-examples" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="comname" class="form-label">Company<span class="text-danger">*</span></label>
                            <input type="text" name="company" required="" value="<?php echo e(old('company')); ?>" class="form-control" id="comname">
                        </div>
                        <div class="mb-3">
                            <label for="comaddress" class="form-label">Address<span class="text-danger">*</span></label>
                            <input type="text" name="address" required="" value="<?php echo e(old('address')); ?>" class="form-control" id="comaddress">
                        </div>
                        <div class="mb-3">
                            <label for="comphone" class="form-label">Phone<span class="text-danger">*</span></label>
                            <input type="integer" name="phone" required="" value="<?php echo e(old('phone')); ?>" class="form-control" id="comphone">
                        </div>
                        <div class="mb-3">
                            <label for="composition" class="form-label">Position<span class="text-danger">*</span></label>
                            <input type="text" name="position" required="" value="<?php echo e(old('position')); ?>" class="form-control" id="composition">
                        </div>
                        <div class="mb-3">
                            <label for="comdepartment" class="form-label">Department<span class="text-danger">*</span></label>
                            <input type="text" name="department" required="" value="<?php echo e(old('department')); ?>" class="form-control" id="comdepartment">
                        </div>
                        <div class="mb-3">
                            <label for="comdescription" class="form-label">Description<span class="text-danger">*</span></label>
                            <textarea name="description" required="" class="form-control" id="comdescription" value="<?php echo e(old('description')); ?>"> </textarea>
                        </div>
                        <div class="mb-3">
                            <label for="comfrom" class="form-label">From<span class="text-danger">*</span></label>
                            <input type="date" name="from" required="" value= "<?php echo e(old('from')); ?>" class="form-control" id="comfrom">
                        </div>
                        <div class="mb-3">
                            <label for="comto" class="form-label">To<span class="text-danger">*</span></label>
                            <input type="date" name="to" required="" value="<?php echo e(old('to')); ?>" class="form-control" id="comto">
                        </div>

                        <div class="text-end">
                            <button class="btn btn-primary waves-effect waves-light" type="submit">Submit</button>
                            <button type="reset" class="btn btn-danger waves-effect">Reset</button>
                            <button type="reset" class="btn btn-secondary waves-effect">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('jobentry.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('jobentry.layout', ['title' => 'Job Entry'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\WDPF-57\Desktop\production\job-portal\resources\views/jobentry/experience/create.blade.php ENDPATH**/ ?>
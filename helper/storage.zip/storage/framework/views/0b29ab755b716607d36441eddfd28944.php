<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('jobentry.inc.jumbotron', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid pt-3 pb-3" data-wow-delay="0.1s">
    <div class="container py-5">
        <h1 class="text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">Project</h1>
        <div class="row g-5">
            <?php echo $__env->make('jobentry.inc.leftsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            <div class="card col-9">
                <div class="card-body">
                    <h4 class="mt-0 header-title">Project Add</h4>
                
                    <table id="datatable" class="table table-bordered dt-responsive table-responsive nowrap">
                        <thead>
                            <tr> 
                                <th>title</th>
                                <th>description</th>
                                <th>url</th>
                                <th>start_date</th>
                                <th>end_date</th>
                                <th>status</th>
                                <th>Action</th>
                             
                                
                            </tr>
                        </thead>
          

                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="odd">
                                <td class="" tabindex="0"><?php echo e($project->title); ?></td>
                                <td class=""><?php echo e($project->description); ?></td>
                                <td class=""><?php echo e($project->url); ?></td>
                                <td class=""><?php echo e(Carbon\Carbon::parse($project->start_date)->format('d/m/y')); ?></td>
                                <td class=""><?php echo e($project->end_date ? Carbon\Carbon::parse($project->end_date)->format('d/m/y') : "continue"); ?></td>
                                <td class=""><?php echo e($project->status); ?></td>
                        
                                <td>
                                    <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                                        <div class="btn-group" role="group">
                                            <button id="btnGroupDrop1" type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="bi bi-arrow-down-square"></i>
                                            </button>
                                            <ul class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                                <li><a class="dropdown-item" href="<?php echo e(route('project.edit', $project->id)); ?>">Edit</a></li>
                                                <form action="<?php echo e(route('project.destroy', $project->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <li><button class="dropdown-item" type="submit">Delete</button></li>
                                                </form>
                                            </ul>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr class="odd">
                                <td class="text-center" colspan="100" style="color: red;">Empty</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('jobentry.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('jobentry.layout', ['title' => 'Job Entry'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\WDPF-57\Desktop\production\job-portal\resources\views/jobentry/project/index.blade.php ENDPATH**/ ?>


<!-- Category Start -->
<div class="container-xxl py-5">
    <div class="container">
        <h1 class="text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">Explore By Employer</h1>
        <div class="row g-4">
            <?php $__currentLoopData = $employers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                <a class="cat-item rounded p-4" href="<?php echo e(route('emp.all', $employer->id)); ?>">
                    <i class="fa fa-3x fa-mail-bulk text-primary mb-4"></i>
                    <h6 class="mb-3"><?php echo e($employer->name); ?></h6>
                    <p class="mb-0">123 Vacancy</p>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!-- Category End --><?php /**PATH C:\Users\user\Desktop\New folder (2)\job-portal\resources\views/jobentry/inc/category.blade.php ENDPATH**/ ?>
<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('jobentry.inc.jumbotron', ['title' => $post->title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Job Detail Start -->
<div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
    <div class="container">
        <div class="row gy-5 gx-4">
            <div class="col-lg-8">
                <div class="d-flex align-items-center mb-5">
                    <img class="flex-shrink-0 img-fluid border rounded" src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="" style="width: 80px; height: 80px;">
                    <div class="text-start ps-4">
                        <h3 class="mb-3"><?php echo e($post->title); ?></h3>
                        <span class="text-truncate me-3"><i class="fa fa-map-marker-alt text-primary me-2"></i><?php echo e($post->address); ?></span>
                        <span class="text-truncate me-3"><i class="fas fa-user text-primary me-2"></i><?php echo e($post->employer->name); ?></span>
                        <span class="text-truncate me-3"><i class="far fa-clock text-primary me-2"></i><?php echo e($post->type); ?></span>
                        <span class="text-truncate me-3"><i class="fas fa-users text-primary me-2"></i><?php echo e($post->vacancy); ?></span>
                    </div>
                </div>

                <div class="mb-5">
                    <h4 class="mb-3">Description</h4>
                    <?php echo html_entity_decode($post->description); ?>

                    <br />
                    <br />
                    <h4 class="mb-3">Basic Information</h4>
                    <hr />
                    <ul class="list-inline">
                        <li><i class="fa fa-star text-primary"></i>&nbsp;Functional:- <?php echo e($post->functional->name); ?></li>
                        <li><i class="fa fa-star text-primary"></i>&nbsp;Industrial:- <?php echo e($post->industrial->name); ?></li>
                        <li><i class="fa fa-star text-primary"></i>&nbsp;Special:- <?php echo e($post->special->name); ?></li>
                        <li><i class="fa fa-star text-primary"></i>&nbsp;Country:- <?php echo e($post->country->name); ?></li>
                        <li><i class="fa fa-star text-primary"></i>&nbsp;State:- <?php echo e($post->state->name); ?></li>
                        <li><i class="fa fa-star text-primary"></i>&nbsp;Salary:- <?php echo e($post->salary); ?></li>
                        <li><i class="fa fa-star text-primary"></i>&nbsp;Vacancy:- <?php echo e($post->vacancy); ?></li>
                        <li><i class="fa fa-star text-primary"></i>&nbsp;Published Date:- <?php echo e(Carbon\Carbon::parse($post->created_at)->format('d M Y')); ?></li>
                        <li><i class="fa fa-star text-primary"></i>&nbsp;Deadline:- <?php echo e(Carbon\Carbon::parse($post->deadline)->format('d M Y')); ?></li>
                        <li><i class="fa fa-star text-primary"></i>&nbsp;Qualification:- <?php echo e($post->qualification); ?></li>
                        <li><i class="fa fa-star text-primary"></i>&nbsp;Contact:- <?php echo e($post->contact); ?></li>
                        <li><i class="fa fa-star text-primary"></i>&nbsp;Email:- <?php echo e($post->email); ?></li>
                        <li><i class="fa fa-star text-primary"></i>&nbsp;Website:- <a href="<?php echo e($post->website); ?>" target="_blank"><?php echo e($post->website); ?></a></li>
                        <?php if($post->file): ?>
                            <li><i class="fa fa-star text-primary"></i>&nbsp;File:- <a href="<?php echo e(asset('storage/'.$post->file)); ?>">Download</a></li> 
                        <?php endif; ?>
                    </UL>
                </div>

                <div class="">
                    <a href="<?php echo e(url('applicant/apply/'.$post->id)); ?>" class="btn btn-primary">Apply Now</a>
                    <a href="<?php echo e(route('post.save', $post->id)); ?>" class="btn btn-primary">Save</a>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="bg-light rounded p-5 mb-4 wow slideInUp" id="functionalSidebar" data-wow-delay="0.1s">
                    <h4 class="mb-4">Functional</h4>
                </div>
                <div class="bg-light rounded p-5 mb-4 wow slideInUp" id="industrialSidebar" data-wow-delay="0.1s">
                    <h4 class="mb-4">Industrial</h4>
                </div>
                <div class="bg-light rounded p-5 mb-4 wow slideInUp" id="specialSidebar" data-wow-delay="0.1s">
                    <h4 class="mb-4">Special</h4>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Job Detail End -->
<?php echo $__env->make('jobentry.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('jobentry.layout', ['title' => 'Job Entry'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\New folder (2)\job-portal\resources\views/jobentry/single.blade.php ENDPATH**/ ?>
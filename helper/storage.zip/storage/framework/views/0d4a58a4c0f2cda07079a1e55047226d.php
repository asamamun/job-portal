<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <h4 class="header-title">Create Form</h4>
        <p class="text-muted font-14">
            Parsley is a javascript form validation library. It helps you provide your users with feedback on their form submission before sending it to your server.
        </p>
        <form action="<?php echo e(route('question.update', $question->id)); ?>" class="parsley-examples" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-2">
                <label for="category" class="form-label">Category<span class="text-danger">*</span></label>
                <select name="category_id" class="form-select" id="category" require>
                    <option value="">Select Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e($question->Category->id == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-2">
                <label for="question" class="form-label">Question<span class="text-danger">*</span></label>
                <textarea name="question" class="form-control" id="question" rows="3"><?php echo e($question->question); ?></textarea>
            </div>
            <div class="row mb-2">
                <div class="col-md-6">
                    <div class="input-group">
                        <label for="optionA" class="btn btn-info option">A</label>
                        <input type="text" name="option_one" class="form-control" id="optionA" value="<?php echo e($question->option_one); ?>" aria-describedby="emailHelp">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                        <label for="optionB" class="btn btn-info option">B</label>
                        <input type="text" name="option_two" class="form-control" id="optionB" value="<?php echo e($question->option_two); ?>" aria-describedby="emailHelp">
                    </div>
                </div>
            </div>
            <div class="row mb-2">
                <div class="col-md-6">
                    <div class="input-group">
                        <label for="optionC" class="btn btn-info option">C</label>
                        <input type="text" name="option_three" class="form-control" id="optionC" value="<?php echo e($question->option_three); ?>" aria-describedby="emailHelp">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                        <label for="optionD" class="btn btn-info option">D</label>
                        <input type="text" name="option_four" class="form-control" id="optionD" value="<?php echo e($question->option_four); ?>" aria-describedby="emailHelp">
                    </div>
                </div>
            </div>
            <div class="row mb-2">
                <div class="col-md-12">
                    <div class="input-group">
                        <label for="CorrectAns" class="btn btn-info">Correct Answer</label>
                        <input type="text" name="answer" class="form-control" id="CorrectAns" value="<?php echo e($question->answer); ?>" aria-describedby="emailHelp">
                    </div>
                </div>
            </div>
            <div class="text-end">
                <button class="btn btn-primary waves-effect waves-light" type="submit">Update</button>
                <button type="reset" class="btn btn-danger waves-effect">Reset</button>
                <button type="reset" class="btn btn-secondary waves-effect">Cancel</button>
            </div>
            
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $(document).on('click', '.option', function() {
            $result = $(this).next().val();
            $('#CorrectAns').val($result);
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminto.layout.admin', ['title' => 'Job Entry', 'name' => 'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\WDPF-57\Desktop\production\job-portal\resources\views/adminto/question/edit.blade.php ENDPATH**/ ?>
<?php if($errors->any()): ?>
<?php echo e($msg = ""); ?>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($msg .= $error); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>alert("<?php echo e($msg); ?>")</script>
<?php endif; ?>


<?php if(session('error')): ?>
<script>
  Swal.fire({
    icon: "error",
    title: "Oops...",
    text: "<?php echo e(session('error')); ?>"
  });
</script>
<?php endif; ?>


<?php if(session('success')): ?>
<script>
  Swal.fire({
    position: "top-end",
    icon: "success",
    title: "<?php echo e(session('success')); ?>",
    showConfirmButton: false,
    timer: 1500
  });
</script>
<?php endif; ?><?php /**PATH C:\Users\ASUS\Desktop\project\job-portal\resources\views/inc/sweetAlert2.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo e($user->name); ?></title>
    
</head>

<body>

    <div id="page">
        <div class="photo-and-name">
            <img src="<?php echo e($user->image != null ? asset("storage/".$user->image) : asset('no_image.png')); ?>" class="photo" alt="Profile Picture">
            <div class="contact-info-box">
                <h1 class="name"><?php echo e($user->name); ?></h1>
                <br>
                <h3 class="job-title"><?php echo e(strtoupper($applicant->title)); ?></h3>
                <p class="contact-details">Phone: +92-344-4XX3-1XX &nbsp; - &nbsp; Email: contact@muhammadovi.com</p>
            </div>
        </div>
        <div id="objective">
            <h3>Objective</h3>
            <p>
                To take a challenging and managerial role in the field of Computer programming and implement the expertise and experience gained in this field to develop complex project with efficiency and quality.
            </p>
        </div>
        <div id="education">
            <h3>Education</h3>
            <table>
                <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="school-1">
                    <td rowspan="2">2002 - 2015</td>
                    <td><b><?php echo e($education->level); ?></b>: ABC School (Standard KG-VIII)</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <div id="work">
            <h3>Experience</h3>
            <table>
                <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="work-1">
                    <td><?php echo e(Carbon\Carbon::parse($experience->form)->format('m/y')); ?> - <?php echo e($experience->to ? Carbon\Carbon::parse($experience->to)->format('m/y') : 'continuing'); ?></td>
                    <td><b>ABC Corp</b>: As an IT Manager and Call Service Representative</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <div id="bio-data">
            <h3>Bio-Data</h3>
            <table>
                <tr>
                    <td>F'Name:</td>
                    <td><b><?php echo e($user->name); ?></b></td>
                </tr>
                <tr>
                    <td>Date of Birth:</td>
                    <td><?php echo e(Carbon\Carbon::parse($applicant->dob)->format('d/m/Y')); ?></td>
                </tr>
                <tr>
                    <td>Age:</td>
                    <td><?php echo e(Carbon\Carbon::parse($applicant->dob)->diffForHumans()); ?></td>
                </tr>
                <tr>
                    <td>CNIC:</td>
                    <td><b>42401-XXXXXXX-7</b></td>
                </tr>
                <tr>
                    <td>Religion:</td>
                    <td><b><?php echo e(ucfirst($applicant->religion)); ?></b></td>
                </tr>
                <tr>
                    <td>Nationality:</td>
                    <td><b>Pakistani</b></td>
                </tr>
                <tr>
                    <td>Marital Status:</td>
                    <td><b>Unmarried</b></td>
                </tr>
            </table>
        </div>
        <a href="<?php echo e(route('cv.download', $user->id)); ?>" style="margin-top: 50px;">Download</a>
    </div>

</body>

</html><?php /**PATH C:\Users\WDPF-57\Desktop\production\job-portal\resources\views/cv/w3schools/index.blade.php ENDPATH**/ ?>